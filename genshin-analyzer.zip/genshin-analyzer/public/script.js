// ===== TextMap =====
let TEXT = {};
async function loadText() {
  if (Object.keys(TEXT).length) return;
  TEXT = await fetch("https://enka.network/api/store/ja").then(r => r.json());
}

// ===== ビルドタイプ & 優先度 =====
const BUILD_TYPE = { CRIT: "crit", EM: "em", HP: "hp", DEF: "def" };
const CHARACTER_BUILD = {
  10000052: BUILD_TYPE.CRIT, 10000041: BUILD_TYPE.CRIT,
  10000054: BUILD_TYPE.EM
};
const BUILD_PRIORITY = {
  crit: ["FIGHT_PROP_CRITICAL", "FIGHT_PROP_CRITICAL_HURT", "FIGHT_PROP_ATTACK_PERCENT", "FIGHT_PROP_CHARGE_EFFICIENCY"],
  em: ["FIGHT_PROP_ELEMENT_MASTERY", "FIGHT_PROP_CHARGE_EFFICIENCY"]
};
const MAINSTAT_OK = {
  crit: { sands: ["FIGHT_PROP_ATTACK_PERCENT","FIGHT_PROP_CHARGE_EFFICIENCY"], goblet: ["FIGHT_PROP_ATTACK_PERCENT","FIGHT_PROP_ELEMENT_DMG"], circlet: ["FIGHT_PROP_CRITICAL","FIGHT_PROP_CRITICAL_HURT"] },
  em: { sands:["FIGHT_PROP_ELEMENT_MASTERY"], goblet:["FIGHT_PROP_ELEMENT_MASTERY"], circlet:["FIGHT_PROP_ELEMENT_MASTERY"] }
};
const ARTIFACT_SLOT = {
  EQUIP_BRACER: "flower", EQUIP_NECKLACE: "plume",
  EQUIP_SHOES: "sands", EQUIP_RING: "goblet", EQUIP_DRESS: "circlet"
};

// ===== スコア =====
function calcArtifactScore(a){
  let s=0;
  a.flat.reliquarySubstats?.forEach(x=>{
    switch(x.appendPropId){
      case "FIGHT_PROP_CRITICAL": s+=x.statValue*2; break;
      case "FIGHT_PROP_CRITICAL_HURT":
      case "FIGHT_PROP_ATTACK_PERCENT":
      case "FIGHT_PROP_CHARGE_EFFICIENCY":
      case "FIGHT_PROP_ELEMENT_MASTERY":
      case "FIGHT_PROP_HP_PERCENT":
      case "FIGHT_PROP_DEFENSE_PERCENT":
        s+=x.statValue; break;
    }
  });
  return s;
}

// ===== 無駄ステ分析 =====
function analyzeArtifact(equip, buildType) {
  let useful=0, useless=0;
  equip.flat.reliquarySubstats?.forEach(sub=>{
    BUILD_PRIORITY[buildType].includes(sub.appendPropId) ? useful++ : useless++;
  });
  return { useful, useless };
}
function isBadArtifact(equip, buildType){ return analyzeArtifact(equip, buildType).useless>=3; }

// ===== メインステ不適合 =====
function getArtifactSlot(e){ return ARTIFACT_SLOT[e.flat.equipType]; }
function isBadMainStat(e, buildType){
  const slot = getArtifactSlot(e);
  const main = e.flat.reliquaryMainstat?.mainPropId;
  const ok = MAINSTAT_OK[buildType]?.[slot];
  return ok ? !ok.includes(main) : false;
}

// ===== MLモデル（TF.js） =====
let model;
async function loadModel() {
  model = tf.sequential();
  model.add(tf.layers.dense({ inputShape:[9], units:16, activation:"relu" }));
  model.add(tf.layers.dense({ units:8, activation:"relu" }));
  model.add(tf.layers.dense({ units:1, activation:"sigmoid" }));
  model.compile({ optimizer:"adam", loss:"meanSquaredError" });
}
function artifactFeatures(equip, buildType){
  const f={crit:0, cd:0, atk:0, er:0, em:0, hp:0, def:0};
  equip.flat.reliquarySubstats?.forEach(s=>{
    switch(s.appendPropId){
      case "FIGHT_PROP_CRITICAL": f.crit+=s.statValue; break;
      case "FIGHT_PROP_CRITICAL_HURT": f.cd+=s.statValue; break;
      case "FIGHT_PROP_ATTACK_PERCENT": f.atk+=s.statValue; break;
      case "FIGHT_PROP_CHARGE_EFFICIENCY": f.er+=s.statValue; break;
      case "FIGHT_PROP_ELEMENT_MASTERY": f.em+=s.statValue; break;
      case "FIGHT_PROP_HP_PERCENT": f.hp+=s.statValue; break;
      case "FIGHT_PROP_DEFENSE_PERCENT": f.def+=s.statValue; break;
    }
  });
  return [f.crit/100, f.cd/100, f.atk/100, f.er/100, f.em/300, f.hp/100, f.def/100,
          isBadMainStat(equip,buildType)?1:0, analyzeArtifact(equip,buildType).useless/4];
}
async function mlScore(equip, buildType){
  return model.predict(tf.tensor([artifactFeatures(equip, buildType)])).dataSync()[0];
}

// ===== UID取得 & フレンド比較 =====
async function fetchUID(uid){ return fetch(`https://YOUR_WORKER/?uid=${uid}`).then(r=>r.json()); }
async function loadFriends(){
  await loadText(); await loadModel();
  const uids=document.getElementById("uids").value.split(",");
  const players = await Promise.all(uids.map(u=>fetchUID(u.trim())));
  const map={};
  players.forEach(p=>p.avatarInfoList.forEach(c=>{
    if(!map[c.avatarId]) map[c.avatarId]=[];
    map[c.avatarId].push(c);
  }));
  renderCompare(map);
}

// ===== 描画 =====
function renderCompare(map){
  const root=document.getElementById("list");
  root.innerHTML="";
  for(const id in map){
    const chars=map[id];
    const avg = chars.reduce((a,c)=>a+calcArtifactScore(c),0)/chars.length;
    const card=document.createElement("div"); card.className="card";
    card.innerHTML = `<div style="font-weight:700;font-size:18px">${TEXT[chars[0].fetterInfo.titleTextMapHash] ?? "不明"}</div>
                      ${chars.map(c=>artifact(c,avg)).join("")}
                      <button onclick="share(this)">画像保存</button>`;
    root.appendChild(card);
  }
}
function artifact(a, avg){
  const s=calcArtifactScore(a);
  const diff=s-avg;
  const bad=isBadArtifact(a, BUILD_TYPE.CRIT);
  return `<div class="artifact ${bad?"bad":""}" onclick="this.classList.toggle('open')">
    <div class="artifact-head">
      <span>★${a.flat.rankLevel+1}</span>
      <span>${s.toFixed(1)} (${((s/45)*100).toFixed(0)}%)</span>
      <span style="color:${diff>=0?'#22c55e':'#ef4444'}">${diff>=0?'+':''}${diff.toFixed(1)}</span>
    </div>
    <div class="artifact-body">
      <div>有効:${analyzeArtifact(a,BUILD_TYPE.CRIT).useful} / 無駄:${analyzeArtifact(a,BUILD_TYPE.CRIT).useless}</div>
      ${a.flat.reliquarySubstats?.map(x=>`${x.appendPropId}+${x.statValue}`).join("<br>")}
    </div>
  </div>`;
}

// ===== 画像共有 =====
async function share(btn){
  const c=btn.closest(".card");
  const canvas=await html2canvas(c, { scale:2 });
  const a=document.createElement("a");
  a.href=canvas.toDataURL();
  a.download="build.png";
  a.click();
}

// ===== データ収集 =====
async function sendArtifactData(equip, buildType, replaced){
  if(!document.getElementById("consent").checked) return;
  const payload={
    features: artifactFeatures(equip, buildType),
    buildType,
    score: calcArtifactScore(equip),
    replaced
  };
  await fetch("https://YOUR_WORKER/collect", { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(payload) });
}