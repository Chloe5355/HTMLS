export default {
  async fetch(req, env) {
    const url = new URL(req.url);

    // データ収集API
    if (url.pathname === "/collect" && req.method === "POST") {
      try {
        const data = await req.json();
        if (!Array.isArray(data.features) || typeof data.score !== "number") {
          return new Response("Invalid data", { status: 400 });
        }
        if (!env.DATASET) return new Response("KV not bound", { status: 500 });

        await env.DATASET.put(
          crypto.randomUUID(),
          JSON.stringify(data)
        );
        return new Response("ok");
      } catch (err) {
        return new Response("error", { status: 500 });
      }
    }

    // UID取得（CORS対応）
    if (url.searchParams.has("uid")) {
      try {
        const uid = url.searchParams.get("uid");
        const res = await fetch(`https://enka.network/api/uid/${uid}`);
        const text = await res.text();
        return new Response(text, {
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
          }
        });
      } catch (err) {
        return new Response("Fetch error", { status: 500 });
      }
    }

    return new Response("Not found", { status: 404 });
  }
};